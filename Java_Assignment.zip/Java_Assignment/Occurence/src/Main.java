import java.util.LinkedList;
public class Main {

  public static void main(String[] args) {

     
     LinkedList<String> list = new LinkedList<String>();

    
     list.add("AA");
     list.add("BB");
     list.add("CC");
     list.add("AA");
     list.add("DD");
     list.add("AA");
     list.add("EE");
 
    
     System.out.println("LinkedList elements: "+list);

 
     System.out.println("LastIndex of AA:"+list.lastIndexOf("AA"));

     
     System.out.println("LastIndex of ZZ:"+list.lastIndexOf("ZZ"));
  }
}