
import java.util.LinkedList; 
  
public class Main { 
   public static void main(String args[]) { 
  
     
      LinkedList list = new LinkedList(); 
  
      // use add() method to add elements in the list 
      list.add("Geeks"); 
      list.add("for"); 
      list.add("Geeks"); 
      list.add("10"); 
      list.add("20"); 
  
      // Output the present list 
      System.out.println("The list is:" + list); 
  
      // Adding new elements to the end 
      list.add("Hello"); 
      list.add("End"); 
  
      // printing the new list 
      System.out.println("The new List is:" + list); 
   } 
}