import java.util.*; 
  
public class Main { 
    public static void main(String[] args) 
    { 
        // Create a TreeSet and inserting elements 
        SortedMap<Integer, String> mp = new TreeMap<>(); 
  
        // Adding Element to SortedSet 
        mp.put(1, "One"); 
        mp.put(2, "Two"); 
        mp.put(3, "Three"); 
        mp.put(4, "Four"); 
        mp.put(5, "Five"); 
  
        // Returning the key ranging 
        // between 2 and 5 
        System.out.print("Elements in range from 2 to 5 in the map is : "
                         + mp.subMap(1, 3)); 
    } 
} 