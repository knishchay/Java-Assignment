import java.util.*;
//import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		List<String> list_Strings = new ArrayList<String>();
		
		 
//			System.out.println("Enter Array elements");
//			Scanner in = new Scanner(System. in);
//			String s= in.nextLine();
//			list_Strings.add(s);
//			
//			System.out.println(list_Strings);
		
		list_Strings.add("Red");
		list_Strings.add("Green");
		list_Strings.add("Orange");
		list_Strings.add("White");
		list_Strings.add("Black");
		
		System.out.println(list_Strings);
		
		list_Strings.add(0, "Pink");
		
		
		System.out.println(list_Strings);

	}

}


